# Digital_Signature_using_DLP
- This folder contains:
	- Evaluation_1_P.py - contains the code for the digital signature.
	- Evaluation_1_P.ipynb - contains the jupyter notebook having the same code.
	- Evaluation_1.webm - video of the implementation.
	- Evaluation_1_Q.pdf - Question 1 written part.

	Video is also available on drive: https://drive.google.com/file/d/16zhS6to0E_uJPmEpkIaiHkFMD1qnROoT/view?usp=sharing
	Also on youtube : https://youtu.be/vyRCtz5Ap4A 